/*
 * File:   main.c
 * Author: ESTG
 */

#include <stdio.h>

#define TAM_STRINGS 10

/*
 * Demonstração de Strings
 */
int main() {

    int i, contador1 = 0, contador2 = 0;
    char primeiroNome[TAM_STRINGS], ultimoNome[TAM_STRINGS], nomeCompleto[(TAM_STRINGS * 2) - 2];

    // ler nomes ---------------------------------------------------------------

    printf("Insira o primeiro nome: \n");
    fgets(primeiroNome, sizeof (primeiroNome), stdin);
    printf("Insira o ultimo nome: \n");
    fgets(ultimoNome, sizeof (ultimoNome), stdin);

    puts(primeiroNome);
    puts(ultimoNome);

    // contar os caracters -----------------------------------------------------

    while (primeiroNome[contador1] != '\0') {
        contador1++;
    }
    while (ultimoNome[contador2] != '\0') {
        contador2++;
    }

    printf("\nO tamanho das strings é %d %d", contador1, contador2);

    // remover o \n ------------------------------------------------------------

    printf("\n%s %s", primeiroNome, ultimoNome);

    if (primeiroNome[contador1 - 1] == '\n') {
        primeiroNome[--contador1] = '\0';
    }
    if (ultimoNome[contador2 - 1] == '\n') {
        ultimoNome[--contador2] = '\0';
    }

    printf("\n%s %s", primeiroNome, ultimoNome);
    printf("\nO tamanho das strings é %d %d", contador1, contador2);

    // Colocar 1 letra em maiusculas -------------------------------------------

    if (primeiroNome[0] > 96 && primeiroNome[0] < 123) {
        primeiroNome[0] -= 32;
    }
    if (ultimoNome[0] > 96 && ultimoNome[0] < 123) {
        ultimoNome[0] -= 32;
    }

    printf("\n%s %s", primeiroNome, ultimoNome);

    // Concatenar---------------------------------------------------------------

    for (i = 0; i < contador1; i++) {
        nomeCompleto[i] = primeiroNome[i];
    }

    nomeCompleto[contador1] = ' ';

    for (i = 0; i < contador2; i++) {
        nomeCompleto[contador1 + i + 1] = ultimoNome[i];
    }

    nomeCompleto[contador1 + contador2 + 1] = '\0';

    printf("\n%s", nomeCompleto);

    return 0;
}
