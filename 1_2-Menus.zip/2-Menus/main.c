/*
 * File:   main.c
 * Author: ESTG
 */
#include <stdio.h>

/*
 * Demonstração de Funções - Menus
 */

void menu1_1() {
    puts("Acedeu à opção 1.1");
}

void menu1_2() {
    puts("Acedeu à opção 1.2");
}

void menu1() {
    int opcao;

    do {
        puts("----------");
        puts("Menu Op. 1");
        puts("----------");
        puts("1. Opção 1.1");
        puts("2. Opção 1.2");
        puts("0. Voltar");

        puts("Insira a sua opção:");
        scanf("%d", &opcao);

        switch (opcao) {
            case 0:
                break;
            case 1:
                menu1_1();
                break;
            case 2:
                menu1_2();
                break;
            default:
                puts("Opção inválida!");
                break;
        }

    } while (opcao != 0);
}

void menu2() {
    int opcao;

    do {
        puts("----------");
        puts("Menu Op. 1");
        puts("----------");
        puts("1. Opção 1.1");
        puts("2. Opção 1.2");
        puts("0. Voltar");

        do {
            puts("Insira a sua opção:");
            scanf("%d", &opcao);
        } while (opcao < 0 || opcao > 2);

        switch (opcao) {
            case 0:
                break;
            case 1:
                menu1_1();
                break;
            case 2:
                menu1_2();
                break;
        }

    } while (opcao != 0);
}

void menu3() {
    puts("Acedeu à opção 3");
}

void menuPrincipal() {
    int opcao;

    do {
        puts("--------------------");
        puts("Menu Principal");
        puts("--------------------");
        puts("1. Opção 1");
        puts("2. Opção 2");
        puts("3. Opção 3");
        puts("0. Sair");
        puts("--------------------");

        puts("Insira a sua opção [0-3]:");
        scanf("%d", &opcao);

        switch (opcao) {
            case 0:
                break;
            case 1:
                menu1(); // com validacao de input
                break;
            case 2:
                menu2(); // sem validacao de input
                break;
            case 3:
                menu3();
                break;
            default:
                puts("Opção inválida!");
                break;
        }

    } while (opcao != 0);
}

int main() {

    menuPrincipal();

    return 0;
}
