/*
 * File:   main.c
 * Author: ESTG
 */

#ifndef MENU2_H
#define MENU2_H

#define TITLE_2 "MENU 1"

void menu2();

#endif /* MENU2_H */
