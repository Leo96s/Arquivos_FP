/*
 * File:   main.c
 * Author: ESTG
 */
#include <stdio.h>

#include "menuPrincipal.h"

/*
 * Demonstração de programação modular
 */

int main() {

    menuPrincipal();

    return 0;
}
