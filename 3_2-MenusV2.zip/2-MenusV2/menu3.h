/*
 * File:   main.c
 * Author: ESTG
 */

#ifndef MENU3_H
#define MENU3_H

#define TITLE_3 "MENU 3"

void menu3();

#endif /* MENU3_H */
