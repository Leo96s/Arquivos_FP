/*
 * File:   main.c
 * Author: ESTG
 */

#ifndef MENU1_H
#define MENU1_H

#define TITLE_1 "MENU 1"

void menu1();

#endif /* MENU1_H */

