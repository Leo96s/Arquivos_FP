/*
 * File:   main.c
 * Author: ESTG
 */

#include <stdio.h>

#include "menu3.h"

void menu3() {
    puts(TITLE_3);
    puts("Acedeu à opção 3");
}