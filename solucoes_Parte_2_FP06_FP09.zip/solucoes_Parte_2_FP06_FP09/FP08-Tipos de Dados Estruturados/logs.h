/*
 * File:   logs.h
 * Author: oscar
 *
 * Created on November 4, 2020, 9:25 AM
 */

#ifndef LOGS_H
#define LOGS_H

void logMsg(char *msg, char *filename);

#endif /* LOGS_H */

