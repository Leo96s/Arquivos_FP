#ifndef ALUNOS_H
#define ALUNOS_H

#define MAX_NOME    30
#define MAX_ALUNOS  30

typedef struct {
    int ano, mes, dia;
} Data;

typedef struct aluno {
    int numero;
    char nome[MAX_NOME];
    Data data_nascimento;
} Aluno;

void preencheAlunos(Aluno [], int);

void imprimeAlunos(Aluno []);

void misturaAlunos(Aluno [], int);

/*
 * PESQUISA
 */

int pesquisaSequencial(Aluno [], int);
int pesquisaSequencialOrdenada(Aluno [], int);
int pesquisaBinaria(Aluno [], int);
int pesquisaBinariaRecursiva(Aluno [], int);

/*
 * ORDENAÇÃO
 */

void bubbleSort(Aluno alunos[]);
void selectionSort(Aluno alunos[]);
void insertionSort(Aluno alunos[]);
void mergeSort(Aluno alunos[]);
void quickSort(Aluno alunos[]);


/*
 * Ficha
 */

int ordenada(Aluno []);
int encontraPorDataNascimento(Aluno [], int, int, int, int);
void imprimePorDataNascimento(Aluno [], int, int, int);
void ordenaPorDataNascimento(Aluno []);
void ordenaPorNome(Aluno []);

#endif /* ALUNOS_H */

