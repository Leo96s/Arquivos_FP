#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "alunos.h"

int obtemNumeroEntre(int lower, int upper) {
    return (rand() % (upper - lower + 1)) +lower;
}

void obtemNome(char *name) {
    int i;
    for (i = 0; i < MAX_NOME - 1; i++) {
        name[i] = obtemNumeroEntre(97, 122);
    }
    name[MAX_NOME - 1] = '\0';
}

void obtemData(Data *data) {
    data->dia = obtemNumeroEntre(1, 31);
    data->mes = obtemNumeroEntre(1, 12);
    data->ano = obtemNumeroEntre(1900, 2021);
}

void preencheAlunos(Aluno alunos[], int seed) {
    int i;

    srand(seed);

    for (i = 0; i < MAX_ALUNOS; i++) {
        alunos[i].numero = i + 1;
        obtemData(&alunos[i].data_nascimento);
        obtemNome(alunos[i].nome);
    }
}

void imprimeAluno(Aluno aluno) {
    printf("\n%d %30s %d-%d-%d", aluno.numero, aluno.nome, aluno.data_nascimento.dia, aluno.data_nascimento.mes, aluno.data_nascimento.ano);
}

void imprimeAlunos(Aluno alunos[]) {
    int i;
    for (i = 0; i < MAX_ALUNOS; i++) {
        imprimeAluno(alunos[i]);
    }
}

void swapAlunos(Aluno *aluno1, Aluno *aluno2) {
    Aluno temp = *aluno1;
    *aluno1 = *aluno2;
    *aluno2 = temp;
}

void misturaAlunos(Aluno alunos[], int seed) {
    int i;

    srand(seed);

    for (i = 0; i < MAX_ALUNOS; i++) {
        swapAlunos(&alunos[i], &alunos[obtemNumeroEntre(0, MAX_ALUNOS - 1)]);
    }
}

/*******************************************************************************
 *
 * PESQUISA
 *
 ******************************************************************************/

int pesquisaSequencial(Aluno alunos[], int numero) {
    int i;
    for (i = 0; i < MAX_ALUNOS; i++) {
        if (alunos[i].numero == numero) {
            return i;
        }
    }
    return -1;
}

int pesquisaSequencialOrdenada(Aluno alunos[], int numero) {
    int i;
    for (i = 0; i < MAX_ALUNOS && (alunos[i].numero <= numero); i++) {
        if (alunos[i].numero == numero) {
            return i;
        }
    }
    return -1;
}

int pesquisaBinaria(Aluno alunos[], int numero) {
    int meio, inicio = 0, fim = MAX_ALUNOS - 1;

    while (inicio <= fim) {
        meio = inicio + ((fim - inicio) / 2);

        if (alunos[meio].numero == numero) {
            return meio;
        }

        if (alunos[meio].numero < numero) {
            inicio = meio + 1;
        } else {
            fim = meio - 1;
        }

    }

    return -1;
}

int binarySearchRecursiva(Aluno alunos[], int numero, int inicio, int fim) {
    if (fim >= inicio) {
        int meio = inicio + ((fim - inicio) / 2);

        if (alunos[meio].numero == numero) {
            return meio;
        }

        return (alunos[meio].numero > numero) ?
                binarySearchRecursiva(alunos, numero, inicio, meio - 1) :
                binarySearchRecursiva(alunos, numero, meio + 1, fim);
    }

    return -1;
}

int pesquisaBinariaRecursiva(Aluno alunos[], int numero) {
    return binarySearchRecursiva(alunos, numero, 0, MAX_ALUNOS - 1);
}

/*******************************************************************************
 *
 * ORDENAÇAO
 *
 ******************************************************************************/

void bubbleSort(Aluno alunos[]) {
    int i, j;
    for (i = 0; i < MAX_ALUNOS - 1; i++) {
        for (j = 0; j < MAX_ALUNOS - i - 1; j++) {
            if (alunos[j].numero > alunos[j + 1].numero) {
                swapAlunos(&alunos[j], &alunos[j + 1]);
            }
        }
    }
}

void selectionSort(Aluno alunos[]) {
    int i, j, min;

    for (i = 0; i < MAX_ALUNOS - 1; i++) {
        min = i;
        for (j = i + 1; j < MAX_ALUNOS; j++) {
            if (alunos[j].numero < alunos[min].numero) {
                min = j;
            }
        }
        swapAlunos(&alunos[min], &alunos[i]);
    }
}

void insertionSort(Aluno alunos[]) {
    int i, j;
    Aluno temp;
    for (i = 1; i < MAX_ALUNOS; i++) {
        temp = alunos[i];
        j = i - 1;

        while (j >= 0 && alunos[j].numero > temp.numero) {
            alunos[j + 1] = alunos[j];
            j = j - 1;
        }

        alunos[j + 1] = temp;
    }
}

void merge(Aluno alunos[], int inicio, int meio, int fim) {
    Aluno temp[fim - inicio + 1];
    int i = inicio, j = meio + 1, k = 0;

    while (i <= meio && j <= fim) {
        if (alunos[i].numero <= alunos[j].numero) {
            temp[k++] = alunos[i++];
        } else {
            temp[k++] = alunos[j++];
        }
    }

    while (i <= meio) {
        temp[k++] = alunos[i++];
    }
    while (j <= fim) {
        temp[k++] = alunos[j++];
    }

    for (i = inicio; i <= fim; i++) {
        alunos[i] = temp[i - inicio];
    }

}

void mergeSortBase(Aluno alunos[], int inicio, int fim) {
    if (inicio < fim) {
        int meio = inicio + ((fim - inicio) / 2);

        mergeSortBase(alunos, inicio, meio);
        mergeSortBase(alunos, meio + 1, fim);

        merge(alunos, inicio, meio, fim);
    }
}

void mergeSort(Aluno alunos[]) {
    mergeSortBase(alunos, 0, MAX_ALUNOS - 1);
}

int partition(Aluno alunos[], int low, int high) {
    int pivot = alunos[high].numero;
    int i = (low - 1), j;
    for (j = low; j <= high - 1; j++) {
        if (alunos[j].numero < pivot) {
            i++;
            swapAlunos(&alunos[i], &alunos[j]);
        }
    }
    swapAlunos(&alunos[i + 1], &alunos[high]);
    return (i + 1);
}

void quickSortBase(Aluno alunos[], int low, int high) {
    if (low < high) {
        int partitioning_index = partition(alunos, low, high);
        quickSortBase(alunos, low, partitioning_index - 1);
        quickSortBase(alunos, partitioning_index + 1, high);
    }
}

void quickSort(Aluno alunos[]) {
    quickSortBase(alunos, 0, MAX_ALUNOS - 1);
}

/*******************************************************************************
 *
 * Ficha
 *
 ******************************************************************************/

int ordenada(Aluno aluno[]) {
    int i;
    for (i = 0; i < MAX_ALUNOS - 1; i++) {
        if (aluno[i].numero > aluno[i + 1].numero) {
            return 0;
        }
    }
    return 1;
}

int encontraPorDataNascimento(Aluno alunos[], int dia, int mes, int ano, int inicio) {
    int i;
    for (i = inicio; i < MAX_ALUNOS; i++) {
        if (alunos[i].data_nascimento.dia == dia && alunos[i].data_nascimento.mes == mes && alunos[i].data_nascimento.ano == ano) {
            return i;
        }
    }
    return -1;
}

void imprimePorDataNascimento(Aluno alunos[], int dia, int mes, int ano) {
    int indice = -1;
    while ((indice = encontraPorDataNascimento(alunos, dia, mes, ano, indice + 1)) != -1) {
        imprimeAluno(alunos[indice]);
    }
}

int comparadorData(Data data1, Data data2) {
    if (data1.ano < data2.ano) {
        return 0;
    }
    if (data1.ano == data2.ano) {
        if (data1.mes < data2.mes) {
            return 0;
        }
        if (data1.mes == data2.mes) {
            return (data1.dia < data2.dia) ? 0 : 1;
        }
        return 1;
    }
    return 1;
}

void ordenaPorDataNascimento(Aluno alunos[]) {
    int i, j;
    for (i = 0; i < MAX_ALUNOS - 1; i++) {
        for (j = 0; j < MAX_ALUNOS - i - 1; j++) {
            if (comparadorData(alunos[j].data_nascimento, alunos[j + 1].data_nascimento)) {
                swapAlunos(&alunos[j], &alunos[j + 1]);
            }
        }
    }
}

void ordenaPorNome(Aluno alunos[]) {
    int i, j, min;

    for (i = 0; i < MAX_ALUNOS - 1; i++) {
        min = i;
        for (j = i + 1; j < MAX_ALUNOS; j++) {
            if (strcmp(alunos[j].nome, alunos[min].nome) < 0) {
                min = j;
            }
        }
        swapAlunos(&alunos[min], &alunos[i]);
    }
}
