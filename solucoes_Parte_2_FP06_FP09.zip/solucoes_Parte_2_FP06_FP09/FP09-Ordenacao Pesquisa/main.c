/*
 * File:   main.c
 * Author: ESTG
 */

#include <stdio.h>

#include "alunos.h"

#define DEBUG 0

int procurarValor() {
    int numero;
    puts("Valor a procurar");
    scanf("%d", &numero);
    return numero;
}

/*
 * Demonstração de algoritmos de pesquisa e ordenações
 */
int main() {
    int valor, seed = 1;
    Aluno alunos[MAX_ALUNOS];

    preencheAlunos(alunos, seed);

    int opcao;
    do {
        printf("\n-----------------------------------------------------------");
        printf("\n1 - Listar");

        printf("\n2 - Pesquisa Sequencial");
        printf("\n3 - Pesquisa Sequencial Ordenada");
        printf("\n4 - Pesquisa Binária");
        printf("\n5 - Pesquisa Binária Recursiva");

        printf("\n6 - Shuffle (Mistura)");

        printf("\n7 - Bubble Sort");
        printf("\n8 - Selection Sort");
        printf("\n9 - Insertion Sort");
        printf("\n10 - Merge Sort");
        printf("\n11 - Quick Sort");

        printf("\n12 - Ordenada\?");
        printf("\n13 - Encontra por data de nascimento");
        printf("\n14 - Imprime por data de nascimento");
        printf("\n15 - Ordena por data de nascimento");
        printf("\n16 - Ordena por nome");

        printf("\n0 - Sair");
        printf("\n------------------------------------------------------------");

        printf("\nOpcao: ");
        scanf("%d", &opcao);

        switch (opcao) {
            case 0:
                break;
            case 1:
                imprimeAlunos(alunos);
                break;
            case 2:
                valor = procurarValor();
                printf("\nPequisa sequencial (valor: %d): %d", valor, pesquisaSequencial(alunos, valor));
                break;
            case 3:
                valor = procurarValor();
                printf("\nPequisa sequencial (valor: %d): %d", valor, pesquisaSequencialOrdenada(alunos, valor));
                break;
            case 4:
                valor = procurarValor();
                printf("\nPequisa sequencial (valor: %d): %d", valor, pesquisaBinaria(alunos, valor));
                break;
            case 5:
                valor = procurarValor();
                printf("\nPequisa sequencial (valor: %d): %d", valor, pesquisaBinariaRecursiva(alunos, valor));
            case 6:
                misturaAlunos(alunos, seed);
                break;
            case 7:
                bubbleSort(alunos);
                break;
            case 8:
                selectionSort(alunos);
                break;
            case 9:
                insertionSort(alunos);
                break;
            case 10:
                mergeSort(alunos);
                break;
            case 11:
                quickSort(alunos);
                break;
            case 12:
                (ordenada(alunos)) ?
                        printf("Os alunos estão ordendados") :
                        printf("Os alunos não estão ordendados");
                break;
            case 13:

                alunos[15].data_nascimento.dia = alunos[15].data_nascimento.mes = alunos[15].data_nascimento.ano = 1;

                printf("\n%d", encontraPorDataNascimento(alunos, 1, 1, 1, 0));
                printf("\n%d", encontraPorDataNascimento(alunos, 2, 1, 1, 0));
                break;
            case 14:

                alunos[15].data_nascimento.dia = alunos[15].data_nascimento.mes = alunos[15].data_nascimento.ano = 1;
                alunos[16].data_nascimento.dia = alunos[16].data_nascimento.mes = alunos[16].data_nascimento.ano = 1;

                imprimePorDataNascimento(alunos, 1, 1, 1);
                break;
            case 15:
                ordenaPorDataNascimento(alunos);
                break;
            case 16:
                ordenaPorNome(alunos);
                break;
            default:
                printf("\nOpcao invalida!");
        }

    } while (opcao != 0);

    return 0;
}
