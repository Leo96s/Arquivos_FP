#include <stdio.h>
#include <stdlib.h>

#define NUM_CIDADES 6
#define TAM_TRAJETO 6

void printMatriz(int cidade[NUM_CIDADES][NUM_CIDADES]) {
    int i, j;
    for (i = 0; i < NUM_CIDADES; i++) {
        puts("");
        for (j = 0; j < NUM_CIDADES; j++) {
            printf("%3d", cidade[i][j]);
        }
    }
}

int verificaSimetria(int cidade[NUM_CIDADES][NUM_CIDADES]) {
    int i, j;
    for (i = 0; i < NUM_CIDADES - 1; i++) {
        for (j = i + 1; j < NUM_CIDADES; j++) {
            if (cidade[i][j] != cidade[j][i]) {
                return 0;
            }
        }
    }
    return 1;
}

int obtemConexao(int cidade1, int cidade2) {
    int op;
    do {
        printf("Insira um valor para %d %d:", cidade1, cidade2);
        scanf("%d", &op);
    } while (op != 0 && op != 1);
    return op;
}

int obtemCidade(char mensagem[]) {
    int cidade;
    do {
        printf("%s", mensagem);
        scanf("%d", &cidade);
    } while (cidade < 0 || cidade >= NUM_CIDADES);
    return cidade;
}

int validaTrajeto(int trajeto[]) {
    int i, j;
    for (i = 0; i < TAM_TRAJETO - 1; i++) {
        for (j = i + 1; j < TAM_TRAJETO; j++) {
            if (trajeto[i] == trajeto[j]) {
                return 0;
            }
        }

    }

    for (i = 0; i < TAM_TRAJETO; i++) {
        if (trajeto[i] < 0 || trajeto[i] >= NUM_CIDADES) {
            return 0;
        }
    }

    return 1;
}

int verificaTrajeto(int trajeto[TAM_TRAJETO], int cidade[NUM_CIDADES][NUM_CIDADES]) {
    int i;
    for (i = 0; i < TAM_TRAJETO - 1; i++) {
        if (cidade[trajeto[i]][trajeto[i + 1]] == 0) {
            return 0;
        }
    }
    return 1;
}

int verificaCircuito(int trajeto[TAM_TRAJETO], int cidade[NUM_CIDADES][NUM_CIDADES]) {
    int i;
    for (i = 0; i < TAM_TRAJETO - 1; i++) {
        if (cidade[trajeto[i]][trajeto[i + 1]] == 0) {
            return 0;
        }
    }
    return cidade[trajeto[0]][trajeto[TAM_TRAJETO - 1]];
}

int verificaDiagonal(int cidade[NUM_CIDADES][NUM_CIDADES]) {
    int i;
    for (i = 0; i < TAM_TRAJETO; i++) {
        if (cidade[i][i] == 0) {
            return 0;
        }
    }
    return 1;
}

int swap(int trajeto[TAM_TRAJETO], int cidade1, int cidade2) {
    int temp;
    temp = trajeto[cidade1];
    trajeto[cidade1] = trajeto[cidade2];
    trajeto[cidade2] = temp;
}

int verificaCaminho(int trajeto[TAM_TRAJETO], int caminho[], int tamanhoCaminho) {
    int i, j, existe;
    for (i = 0; i < TAM_TRAJETO - tamanhoCaminho + 1; i++) {
        existe = 1;
        for (j = 0; j < tamanhoCaminho && existe; j++) {
            if (trajeto[i + j] != caminho[j]) {
                existe = 0;
            }
        }
        if (existe) {
            return 1;
        }
    }
    return 0;
}

int viavel(int cidade[NUM_CIDADES][NUM_CIDADES], int trajeto[TAM_TRAJETO], int cidade1, int cidade2) {
    if (cidade1 == 0 && cidade[trajeto[cidade2]][trajeto[1]] == 0) {
        return 0;
    } else if (cidade1 == (TAM_TRAJETO - 1) && cidade[trajeto[cidade2]][trajeto[TAM_TRAJETO - 1]] == 0) {
        return 0;
    } else if (cidade[trajeto[cidade2]][trajeto[cidade1 - 1]] == 0 || cidade[trajeto[cidade2]][trajeto[cidade1 + 1]] == 0) {
        return 0;
    }
    return 1;
}

int swapViavel(int cidade[NUM_CIDADES][NUM_CIDADES], int trajeto[TAM_TRAJETO], int cidade1, int cidade2) {

    if (!viavel(cidade, trajeto, cidade1, cidade2) && !viavel(cidade, trajeto, cidade2, cidade1)) {
        return 0;
    }

    swap(trajeto, cidade1, cidade2);
    return 1;
}

void versao_a() {
    int i, j;

    int trajeto[TAM_TRAJETO] = {0, 2, 1, 3, 4, 5};
    int trajeto2[TAM_TRAJETO] = {0, 1, 2, 3, 4, 5};

    int cidades[NUM_CIDADES][NUM_CIDADES] = {
        {1, 0, 1, 0, 0, 1},
        {0, 1, 1, 1, 0, 1},
        {1, 1, 1, 0, 1, 1},
        {0, 1, 0, 1, 1, 0},
        {0, 0, 1, 1, 1, 1},
        {1, 1, 1, 0, 1, 1}
    };
    int cidades2[NUM_CIDADES][NUM_CIDADES];

    // 1
    printf("\n%d", verificaTrajeto(trajeto, cidades));
    printf("\n%d", verificaTrajeto(trajeto2, cidades));

    // 2
    for (i = 0; i < NUM_CIDADES - 1; i++) {
        cidades2[i][i] = 1;
        for (j = i + 1; j < NUM_CIDADES; j++) {
            cidades2[i][j] = cidades2[j][i] = obtemConexao(i, j);
        }
    }

    printMatriz(cidades2);

    // 3
    //cidades[1][0] = !cidades[1][0];
    printf("\n%d", verificaSimetria(cidades));
    printf("\n%d", verificaSimetria(cidades2));

    // 4
    printf("\n%d", validaTrajeto(trajeto));
    printf("\n%d", validaTrajeto(trajeto2));
}

void versao_b() {
    int i, j;

    int trajeto[TAM_TRAJETO] = {0, 2, 1, 3, 4, 5};
    int trajeto2[TAM_TRAJETO] = {0, 1, 2, 3, 4, 5};
    int trajeto3[TAM_TRAJETO] = {0, 2, 5, 3, 4, 1};

    int cidades[NUM_CIDADES][NUM_CIDADES] = {
        {1, 0, 1, 0, 0, 1},
        {0, 1, 1, 1, 0, 1},
        {1, 1, 1, 0, 1, 1},
        {0, 1, 0, 1, 1, 0},
        {0, 0, 1, 1, 1, 1},
        {1, 1, 1, 0, 1, 1}
    };
    int cidades2[NUM_CIDADES][NUM_CIDADES];


    // 1
    printf("\n%d", verificaCircuito(trajeto, cidades));
    printf("\n%d", verificaCircuito(trajeto2, cidades));
    printf("\n%d", verificaCircuito(trajeto3, cidades));

    // 2
    //cidades[2][2] = 0;
    printf("\n%d", verificaDiagonal(cidades));

    // 2
    printMatriz(cidades);

    // 3
    for (i = 0; i < NUM_CIDADES - 1; i++) {
        cidades2[i][i] = 1;
        for (j = i + 1; j < NUM_CIDADES; j++) {
            cidades2[i][j] = cidades2[j][i] = obtemConexao(i, j);
        }
    }

    // 4
    printf("\n-->%d", swapViavel(cidades, trajeto, 0, 5));

}

void versao_c() {
    int i, j;

    int trajeto[TAM_TRAJETO] = {0, 2, 1, 3, 4, 5};
    int trajeto2[TAM_TRAJETO] = {0, 1, 2, 3, 4, 5};
    int trajeto3[TAM_TRAJETO] = {0, 2, 5, 3, 4, 1};

    int cidades[NUM_CIDADES][NUM_CIDADES] = {
        {1, 0, 1, 0, 0, 1},
        {0, 1, 1, 1, 0, 1},
        {1, 1, 1, 0, 1, 1},
        {0, 1, 0, 1, 1, 0},
        {0, 0, 1, 1, 1, 1},
        {1, 1, 1, 0, 1, 1}
    };
    int cidades2[NUM_CIDADES][NUM_CIDADES];

    // 1
    int caminho[3] = {3, 4, 5};
    printf("\n%d", verificaCaminho(trajeto, caminho, 3));

    // 2
    printf("%d", obtemCidade("\nInsira uma cidade:"));

    // 3
    int caminho2[3];
    puts("");
    for (i = 0; i < 3; i++) {
        caminho2[i] = obtemCidade("\nInsira uma cidade:");
    }

    puts("");
    for (i = 0; i < TAM_TRAJETO; i++) {
        trajeto2[i] = obtemCidade("\nInsira uma cidade:");
    }

    printf("\n%d", verificaCaminho(trajeto2, caminho2, 3));

    // 4
    printf("\n-->%d", swapViavel(cidades, trajeto, 0, 5));

}

int main() {

    versao_a();
    //versao_b();

    /*
        versao_c();
     */

    return 0;
}

